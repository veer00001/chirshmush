import React from "react";
import "./HomeTab.css";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";

const HomeTab = () => {
  return (
    <div className="homeTab-parant">
      <Tab.Container id="left-tabs-example" defaultActiveKey="first">
        <Row>
          
          <Col sm={3} className="tabHeading">
            <Nav variant="pills" className="flex-column">
              <Nav.Item>
                <Nav.Link eventKey="first">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="second">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Thrid">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Fourth">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Search Engine Optimization</Nav.Link>
              </Nav.Item>
            </Nav>
          </Col>
          <Col sm={9}>
            <Tab.Content>
              <Tab.Pane eventKey="first">
                <h2>Search Engine Optimization</h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Local SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Mobile SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> eCommerce-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Amazon-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Link-Building</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Content-Writing</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> SEO-Reseller</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Panda-Recovery</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Online-Presence-Analysis</Link>{" "}
                    </li>
                  </ul>
                </div>
              </Tab.Pane>
              <Tab.Pane eventKey="second">Second tab content</Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </div>
  );
};

export default HomeTab;
