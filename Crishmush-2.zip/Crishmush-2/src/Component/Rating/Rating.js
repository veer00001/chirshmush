import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import React from "react";

import "./Rating.css";

const Rating = () => {
  return (
    <div>
      <section class="rating-parant">
        <div class="row text-center">

      {/* <div className="text-start container blue-line-bg">Our Rating Your Trust</div> */}
          

          <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/Clutch.webp"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                width="150"
                alt=""
                height="150"
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div>

          
          <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/goo-re.png"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                width="150"
                height="150"
                alt=""
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div>

          
          <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/glassdoor-logo.png"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                alt=""
                width="150"
                height="150"
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div>
 

          {/* <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/sulekha1.png"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                width="150"
                height="150"
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div>

          <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/justdial_logo.png"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                width="150"
                height="150"
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div>
     
          <div class="col-md-4 mb-5 mb-md-0">
            <div class="d-flex justify-content-center">
              <img
                src="https://www.webbraininfotech.com/img/trustpilot.png"
                class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                width="150"
                height="150"
              />
            </div>
            <ul class="list-unstyled d-flex justify-content-center mb-0">
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
              <li>
                <FontAwesomeIcon icon={faStar} color="#ffc107" />
              </li>
            </ul>
          </div> */}

          
        </div>
      </section>
    </div>
  );
};

export default Rating;
