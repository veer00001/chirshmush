import React from "react";
import Home from "./Component/Home";
import Header from "./Component/Header/Header";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navabar from "./Component/Navbar/Navabar";
import MainForm from "./Component/MainForm/MainForm";

const App = () => {
  return (
    <BrowserRouter>
      <Header />
      <Navabar />
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
      <MainForm/>
    </BrowserRouter>
  );
};

export default App;
